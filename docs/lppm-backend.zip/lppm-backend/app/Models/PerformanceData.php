<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PerformanceData extends Model
{
    protected $table = 'performance_data';

    // Validasi dilakukan di controller; kolom id & timestamp dikelola Laravel.
    protected $guarded = ['id'];

    public function program()
    {
        return $this->belongsTo(Program::class);
    }
}
