<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    protected $table = 'programs';

    // Validasi dilakukan di controller; kolom id & timestamp dikelola Laravel.
    protected $guarded = ['id'];
}
