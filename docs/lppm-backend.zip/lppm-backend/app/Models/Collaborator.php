<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Collaborator extends Model
{
    protected $table = 'collaborators';

    // Validasi dilakukan di controller; kolom id & timestamp dikelola Laravel.
    protected $guarded = ['id'];
}
