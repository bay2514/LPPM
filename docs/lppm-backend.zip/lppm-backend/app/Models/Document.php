<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    protected $table = 'documents';

    // Validasi dilakukan di controller; kolom id & timestamp dikelola Laravel.
    protected $guarded = ['id'];
}
