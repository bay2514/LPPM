<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'setting_key';
    public $incrementing = false;
    protected $keyType = 'string';

    // Tabel settings hanya punya kolom updated_at.
    const CREATED_AT = null;

    protected $guarded = [];

    protected $casts = [
        'value' => 'array',
    ];
}
