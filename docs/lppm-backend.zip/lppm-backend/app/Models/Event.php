<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $table = 'events';

    // Validasi dilakukan di controller; kolom id & timestamp dikelola Laravel.
    protected $guarded = ['id'];

    protected $casts = [
        'date' => 'date:Y-m-d',
    ];
}
