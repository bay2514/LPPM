<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    protected $table = 'news';

    // Validasi dilakukan di controller; kolom id & timestamp dikelola Laravel.
    protected $guarded = ['id'];

    protected $casts = [
        'date' => 'date:Y-m-d',
        'publish_at' => 'datetime',
    ];
}
