<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        $email = env('ADMIN_EMAIL');
        $password = env('ADMIN_PASSWORD');

        if (! $email || ! $password) {
            throw new \RuntimeException(
                'Isi ADMIN_EMAIL dan ADMIN_PASSWORD di file .env sebelum menjalankan seeder ini.'
            );
        }

        $user = User::firstOrNew(['email' => strtolower(trim($email))]);
        $user->forceFill([
            'name' => 'Administrator LPPM',
            'password' => Hash::make($password),
            'role' => 'admin',
        ])->save();
    }
}
